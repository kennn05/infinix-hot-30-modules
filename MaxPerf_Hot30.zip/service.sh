#!/system/bin/sh
# Max Performance Hot 30 v1.0
# Late-start only: runs after the system is up. Nothing here touches
# the boot image, system apps, or any file on disk. Every change is
# a runtime write that vanishes on reboot if the module is removed.
#
# This module maxes everything AT ITS FACTORY CAP. It cannot exceed
# the kernel's limits: for each CPU policy it reads the chip's own
# cpuinfo_max_freq and writes it back as the max, so the cap is the
# chip's own, never a guessed number.
#
# DEVICE GUARD: checks for MediaTek hardware (/proc/ppm), never the
# model name, so device-spoof modules cannot fool or break it.
# Every write is existence-guarded: nodes that do not exist on this
# phone are skipped silently.

[ -d /proc/ppm ] || exit 0

w() { [ -w "$1" ] && echo "$2" > "$1" 2>/dev/null; }

# CPU: performance governor on every policy, max freq = factory cap
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -d "$p" ] || continue
  if [ -r "$p/cpuinfo_max_freq" ]; then
    w "$p/scaling_max_freq" "$(cat "$p/cpuinfo_max_freq")"
  fi
  w "$p/scaling_governor" "performance"
done

# All cores online, core control off (no core parking)
for c in /sys/devices/system/cpu/cpu[0-9]*; do
  [ -d "$c" ] || continue
  w "$c/online" "1"
  w "$c/core_ctl/enable" "0"
done

# GPU and buses: performance governor on every devfreq device
# (includes the Mali GPU on this phone)
for d in /sys/class/devfreq/*; do
  [ -d "$d" ] || continue
  w "$d/governor" "performance"
done

# I/O: lowest-latency scheduler (fall back to mq-deadline) +
# 1024KB read-ahead on real storage only (no loop/ram/zram)
for b in /sys/block/sd* /sys/block/mmcblk*; do
  [ -d "$b" ] || continue
  if [ -w "$b/queue/scheduler" ]; then
    echo "none" > "$b/queue/scheduler" 2>/dev/null || echo "mq-deadline" > "$b/queue/scheduler" 2>/dev/null
  fi
  w "$b/queue/read_ahead_kb" "1024"
done

# Let games use all cores (guarded: absent on newer Android, skipped)
for s in top-app foreground background; do
  w "/dev/cpuset/$s/cpus" "0-7"
done

exit 0
