#!/system/bin/sh
# Termux WhatsApp Persist v1.0 - Ken ordered, careful version
# Rule, Ken ordered: only Termux and WhatsApp persist after swipe.
# Other apps stop normally. No auto-start except WhatsApp.
# This script runs AFTER boot, via Magisk service stage only.
# No early-boot script, no system partition changes, no app launch.
# If anything fails, script continues and exits 0, so boot is never blocked.
MODDIR=${0%/*}
# Wait for boot completed, max 120 seconds, then continue anyway
i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ $i -lt 24 ]; do
  sleep 5
  i=$((i + 1))
done
# Log, best effort only
echo "$(date) TermuxWhatsAppPersist start, boot_completed=$(getprop sys.boot_completed)" >> "$MODDIR/last-run.log" 2>/dev/null || true
# Normal Doze / Standby ON, so other apps stop normally
settings put global app_standby_enabled 1 2>/dev/null || true
settings put global device_idle_enabled 1 2>/dev/null || true
dumpsys deviceidle enable 2>/dev/null || true
# Whitelist Termux and WhatsApp only, Ken ordered
dumpsys deviceidle whitelist +com.termux 2>/dev/null || true
dumpsys deviceidle whitelist +com.whatsapp 2>/dev/null || true
cmd appops set com.termux RUN_ANY_IN_BACKGROUND allow 2>/dev/null || true
cmd appops set com.whatsapp RUN_ANY_IN_BACKGROUND allow 2>/dev/null || true
cmd appops set com.termux AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore 2>/dev/null || true
cmd appops set com.whatsapp AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore 2>/dev/null || true
# Remove whitelist / background allow for other third-party apps,
# dynamically, no fixed list except Termux and WhatsApp above.
# If pm list fails, loop does nothing, script still exits 0.
for p in $(pm list packages -3 2>/dev/null | cut -d: -f2); do
  case "$p" in
    com.termux|com.whatsapp) continue ;;
  esac
  dumpsys deviceidle whitelist -$p 2>/dev/null || true
  cmd appops set $p RUN_ANY_IN_BACKGROUND default 2>/dev/null || true
  cmd appops set $p AUTO_REVOKE_PERMISSIONS_IF_UNUSED default 2>/dev/null || true
done
echo "$(date) TermuxWhatsAppPersist done" >> "$MODDIR/last-run.log" 2>/dev/null || true
exit 0
