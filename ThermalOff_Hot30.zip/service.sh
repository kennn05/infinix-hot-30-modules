#!/system/bin/sh
# Thermal Off - Hot 30 v1.0
# Runs at late_start (after the system is up). Nothing here touches
# the boot image, system apps, or any file on disk: every change is
# a runtime write that vanishes on reboot if the module is removed.
#
# DEVICE GUARD (important): this does NOT check the phone's model
# name, because a device-spoof module changes the model name.
# It checks for MediaTek hardware instead (/proc/ppm exists only
# on MediaTek phones), so spoof modules cannot fool it or break it.
# Every write is also guarded by an existence check, so nodes that
# do not exist on this phone are simply skipped.

[ -d /proc/ppm ] || exit 0

w() { [ -w "$1" ] && echo "$2" > "$1" 2>/dev/null; }

# 1. Disable every kernel thermal zone: with a zone disabled, its
# governor makes no throttling decisions at all.
for z in /sys/class/thermal/thermal_zone*; do
  [ -d "$z" ] || continue
  w "$z/mode" "disabled"
  # 2. Backup: raise every trip point to 115C, so even a zone
  # that refuses "disabled" will not trip until near the
  # hardware's own shutdown limit.
  for t in "$z"/trip_point_*_temp; do
    [ -w "$t" ] && echo 115000 > "$t" 2>/dev/null
  done
done

# 3. Force all cooling devices to idle state.
for c in /sys/class/thermal/cooling_device*; do
  [ -d "$c" ] || continue
  w "$c/cur_state" "0"
done

exit 0
