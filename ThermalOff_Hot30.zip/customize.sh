#!/sbin/sh
ui_print "- Thermal Off - Hot 30 v1.0"
ui_print "- Runs after system is up (late-start only)"
ui_print "- Thermal throttling will be OFF after reboot"
ui_print "! Watch temperatures while gaming"
ui_print "! To restore stock thermal: remove module + reboot"
