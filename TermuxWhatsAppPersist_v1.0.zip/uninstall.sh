#!/system/bin/sh
# Uninstall: do nothing dangerous, just exit cleanly.
# Settings applied by service.sh persist until manually changed.
exit 0
