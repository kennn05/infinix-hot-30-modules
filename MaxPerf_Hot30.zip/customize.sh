#!/sbin/sh
ui_print "- Max Performance Hot 30 v1.0"
ui_print "- CPU/GPU at factory cap, all cores online"
ui_print "- Runs after system is up (late-start only)"
ui_print "- Reboot to activate"
ui_print "- To restore stock: remove module + reboot"
